## TESTE ITAÚ BBA ##
> JONATHAN SANTOS 

## COMPLEMENTARES ##
>    "cep-promise": "^4.1.0", // PARA O CEP
>    "ngx-mask": "^12.0.0", // MASCARAR COMPOS DE DADOS
>    "ngx-toastr": "^13.2.1",  //NOTIFICAÇÕES
>    "@angular/material": "^11.2.13", //INTERFACE
>    "lodash": "^4.17.21", // DESEMPENHO

## PARA EXECUTAR ##
Via terminalm estando na pasta do projeto,instalar as dependências:
> npm install 

Para rodar o programa:
> npm start ou ng serve 